from setuptools import setup, find_packages

setup(
    name = 'paquete actividad 34',
    version = '1.0',
    packages=find_packages(),
    description = 'Paquete para gestionar calificaiones de los estudiantes',
    author = 'Diana Martínez',
    author_email = 'petitedifer@gmail.com',
)